import './App.css';
import CustomTable from './CustomTable/CustomTable';
import uuid from 'react-uuid';
import { useState } from "react";
import styles from "./CustomTable.module.css"

function App() {

  const headers = [
    {
      dataIndex: "name",
      title: "Name",
      width: 120,
      sorter: true
    },
    {
      dataIndex: "surname",
      title: "Surname",
      width: 120,
      sorter: false
    },
    {
      dataIndex: "rate",
      title: "Rating",
      width: 120,
      sorter: true
    }
  ];

  const data = [
    {
      name: "Seda",
      surname: "Zaqaryan",
      rate: 102,
      id: uuid(),
    },
    {
      name: "Ruben",
      surname: "Gabrielyan",
      rate: 99,
      id: uuid(),
    },
    {
      name: "Armen",
      surname: "Kirakosyan",
      rate: 77,
      id: uuid(),
    },
    {
      name: "Grisha",
      surname: "Stepanyan",
      rate: 44,
      id: uuid(),
    },
    {
      name: "Seda",
      surname: "Zaqaryan",
      rate: 102,
      id: uuid(),
    },
    {
      name: "Ruben",
      surname: "Gabrielyan",
      rate: 99,
      id: uuid(),
    },
    {
      name: "Armen",
      surname: "Kirakosyan",
      rate: 77,
      id: uuid(),
    },
    {
      name: "Grisha",
      surname: "Stepanyan",
      rate: 44,
      id: uuid(),
    },
    {
      name: "Seda",
      surname: "Zaqaryan",
      rate: 102,
      id: uuid(),
    },
    {
      name: "Ruben",
      surname: "Gabrielyan",
      rate: 99,
      id: uuid(),
    },
    {
      name: "Armen",
      surname: "Kirakosyan",
      rate: 77,
      id: uuid(),
    },
    {
      name: "Grisha",
      surname: "Stepanyan",
      rate: 44,
      id: uuid(),
    },
    {
      name: "Seda",
      surname: "Zaqaryan",
      rate: 102,
      id: uuid(),
    },
    {
      name: "Ruben",
      surname: "Gabrielyan",
      rate: 99,
      id: uuid(),
    },
    {
      name: "Armen",
      surname: "Kirakosyan",
      rate: 77,
      id: uuid(),
    },
    {
      name: "Grisha",
      surname: "Stepanyan",
      rate: 44,
      id: uuid(),
    },
    {
      name: "Seda",
      surname: "Zaqaryan",
      rate: 102,
      id: uuid(),
    },
    {
      name: "Ruben",
      surname: "Gabrielyan",
      rate: 99,
      id: uuid(),
    },
    {
      name: "Armen",
      surname: "Kirakosyan",
      rate: 77,
      id: uuid(),
    },
    {
      name: "Grisha",
      surname: "Stepanyan",
      rate: 44,
      id: uuid(),
    },
    
  ];




  return (
    <div className="App">
      <CustomTable
        headers={headers}
        data={data}
        onItemClick={(item) => console.log(item)}
        onFilter={() => ({ mode: 'asc', field: 'name' })}
        onRemoveItems={(deletedItems) => console.log(deletedItems)}
        selectAll={true}
      />

    </div>
  );
}

export default App;
