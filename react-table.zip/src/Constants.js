export const Constants = {
    asc: "asc",
    desc: "desc"
}