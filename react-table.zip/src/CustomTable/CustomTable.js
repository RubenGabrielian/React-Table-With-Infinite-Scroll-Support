import React, { useEffect, useState } from "react";
import styles from "../CustomTable.module.css";
import { Constants } from "../Constants";
import TableTh from "./Th";
import TableTr from "./Tr";

const CustomTable = ({ headers, data, onFilter, onRemoveItems, selectAll, onItemClick }) => {

    const modifiedDataToChecked = data.map((dataItem) => (
        { ...dataItem, isChecked: false }
    ));



    const [filterMode, setFilterMode] = useState(onFilter ? onFilter().mode : '');
    const [filterField, setFilterField] = useState(onFilter ? onFilter().field : '');
    const [localData, setLocalData] = useState(modifiedDataToChecked);


    useEffect(() => {

        if (filterMode && filterField) {
            let sortedData = [];
            if (filterMode === Constants.asc) {
                sortedData = [...localData].sort((a, b) => (a[filterField] < b[filterField] ? -1 : 1))
            } else if (filterMode === Constants.desc) {
                sortedData = [...localData].sort((a, b) => (a[filterField] > b[filterField] ? -1 : 1))
            }
            setLocalData(sortedData);
        }

    }, [filterMode, filterField]);



    const sortTable = (fieldName) => {
        setFilterField(fieldName);
        const filterModeCheck = filterMode === Constants.asc ? Constants.desc : Constants.asc;
        setFilterMode(filterModeCheck);
        onFilter(filterModeCheck, fieldName);
    }


    const handleSelectAll = () => {
        const selectedAllData = localData.map((data) => {
            return (
                { ...data, isChecked: !data.isChecked }
            )
        });
        setLocalData(selectedAllData);
    }

    const handleSelectItem = (data) => {

        const filteredItems = localData.map((dataItem) => {
            if (dataItem.id === data.id) {
                return data;
            }
            return dataItem;
        });

        setLocalData(filteredItems);
    }

    const handleDelete = () => {

        const deletedItems = localData.filter((dataItem) => dataItem.isChecked);
        onRemoveItems(deletedItems);

        const remainedItems = localData.filter((dataItem) => !dataItem.isChecked);
        setLocalData(remainedItems);

    }



    const checkIsCheckedCount = () => {
        const isCheckedCount = localData.filter((data) => (data.isChecked)).length;
        return !(!isCheckedCount || isCheckedCount === localData.length);
    }




    return (
        <>
            <table className={styles.customTable}>
                <thead>
                    <tr className={styles.customTableTr}>
                        <th className={styles.customTableTh}>Select All</th>
                        {headers ? headers.map((header, key) =>
                            <TableTh
                                key={key}
                                header={header}
                                sortTable={sortTable}
                            />
                        ) : false}
                    </tr>
                </thead>
                <tbody>
                    {localData ? localData.map((dataItem, key) => {
                        return (
                            <TableTr
                                key={key}
                                dataItem={dataItem}
                                deleteCheckboxChange={onRemoveItems}
                                headers={headers}
                                handleSelectItem={handleSelectItem}
                                onItemClick={onItemClick}
                            />
                        )
                    }) : false}
                </tbody>
            </table>
            <div style={{ display: "flex" }}>
                {
                    selectAll && (
                        <button
                            onClick={() => handleSelectAll()}
                            className={styles.selectAll}
                            disabled={checkIsCheckedCount()}
                        >
                            <span>Select All</span>
                        </button>
                    )
                }

                <button onClick={handleDelete} className={styles.removeBtn}>Delete</button>
            </div>
        </>
    )
}

export default CustomTable;